﻿using Abp.Application.Services.Dto;

namespace MyCompanyName.AbpZeroTemplate.Authorization.Roles.Dto
{
    public class GetRolesInput 
    {
        public string Permission { get; set; }
    }
}
