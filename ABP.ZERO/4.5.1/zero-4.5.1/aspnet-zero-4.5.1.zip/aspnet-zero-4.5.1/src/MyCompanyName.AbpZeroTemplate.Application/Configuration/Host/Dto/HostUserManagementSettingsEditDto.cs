﻿namespace MyCompanyName.AbpZeroTemplate.Configuration.Host.Dto
{
    public class HostUserManagementSettingsEditDto
    {
        public bool IsEmailConfirmationRequiredForLogin { get; set; }
    }
}