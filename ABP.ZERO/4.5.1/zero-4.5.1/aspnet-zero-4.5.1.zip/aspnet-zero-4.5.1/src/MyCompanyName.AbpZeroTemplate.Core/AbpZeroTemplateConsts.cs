﻿namespace MyCompanyName.AbpZeroTemplate
{
    /// <summary>
    /// Some general constants for the application.
    /// </summary>
    public class AbpZeroTemplateConsts
    {
        public const string LocalizationSourceName = "AbpZeroTemplate";

        public const bool MultiTenancyEnabled = true;
    }
}