﻿These empty view and controllers can be used to start new pages/modals.

index.js & index.cshtml: For pages.
modal.js & modal.cshtml: For modals.