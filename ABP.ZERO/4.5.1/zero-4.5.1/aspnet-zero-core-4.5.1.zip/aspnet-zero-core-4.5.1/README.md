# ASP.NET ZERO

This repository contains two solutions:

1. ``aspnet-core`` folder contains ASP.NET Core based backend solution. It also contains MVC UI.
2. ``angular`` folder contains Angular 2+ UI that uses ``aspnet-core`` solution as backend.
