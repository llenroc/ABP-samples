﻿export interface IUserWithOrganizationUnit {
    userId: number;
    ouId: number;
}