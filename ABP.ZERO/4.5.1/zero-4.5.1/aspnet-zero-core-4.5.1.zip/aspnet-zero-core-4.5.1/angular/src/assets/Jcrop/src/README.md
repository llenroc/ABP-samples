## Javascript source files

The files in this path are Javascript fragments that are compiled together
to create the Jcrop.js source file. Also includes LESS CSS source files.

##### Building with Grunt

    $ npm install
    $ grunt

##### Grunt watch

The Grunt configuration also includes a watch task using grunt-watch.
Using `watch` (in a different terminal) will allow you to modify files
and have them automatically recompile when changes are detected.

    $ grunt watch
 
Read the [grunt documentation](http://gruntjs.com) for more info.
