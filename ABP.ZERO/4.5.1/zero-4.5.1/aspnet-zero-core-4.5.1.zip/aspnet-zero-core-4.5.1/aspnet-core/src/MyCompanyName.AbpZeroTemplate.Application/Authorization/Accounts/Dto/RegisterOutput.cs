namespace MyCompanyName.AbpZeroTemplate.Authorization.Accounts.Dto
{
    public class RegisterOutput
    {
        public bool CanLogin { get; set; }
    }
}