﻿namespace MyCompanyName.AbpZeroTemplate.Authorization.Users.Profile.Dto
{
    public class UpdateGoogleAuthenticatorKeyOutput
    {
        public string QrCodeSetupImageUrl { get; set; }
    }
}
