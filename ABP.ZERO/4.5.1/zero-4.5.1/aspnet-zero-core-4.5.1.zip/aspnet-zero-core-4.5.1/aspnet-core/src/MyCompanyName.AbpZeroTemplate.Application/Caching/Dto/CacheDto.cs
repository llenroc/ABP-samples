﻿namespace MyCompanyName.AbpZeroTemplate.Caching.Dto
{
    public class CacheDto
    {
        public string Name { get; set; }
    }
}
